"""CICO E-Wallet user interface screens."""
