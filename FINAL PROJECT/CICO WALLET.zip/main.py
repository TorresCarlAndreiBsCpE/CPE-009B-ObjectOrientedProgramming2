import os
import traceback
import tkinter as tk
from tkinter import messagebox

from ui.login_page import LoginPage
from ui.dashboard import Dashboard

# File path of the application icon.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_FILE = os.path.join(BASE_DIR, "CICO.ico")

# ------ Application Parent Class Implementation------
class CICOApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("CICO E-Wallet")
        self.root.geometry("1100x700")
        self.root.minsize(850, 700)
        self.root.configure(bg="#F8F7FF")

        # Track the currently displayed screen.
        self.current_screen = None

        self.set_window_icon()
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)

        # Show unexpected errors in a message box (not just the terminal).
        self.root.report_callback_exception = self.report_error

        self.show_login()

    def set_window_icon(self):
        """Use the CICO icon for every window of the app."""
        if not os.path.isfile(ICON_FILE):
            print(f"Icon file not found: {ICON_FILE}")
            return

        try:
            self.root.iconbitmap(default=ICON_FILE)
        except tk.TclError as error:
            print(f"Could not load CICO.ico: {error}")

    def report_error(self, exc_type, exc_value, exc_traceback):
        traceback.print_exception(exc_type, exc_value, exc_traceback)

        try:
            messagebox.showerror(
                "Unexpected Error",
                f"Something went wrong:\n\n{exc_value}",
                parent=self.root
            )
        except tk.TclError:
            pass

    def clear_screen(self):
        """Remove everything from the current screen."""
        for widget in self.root.winfo_children():
            try:
                widget.destroy()
            except tk.TclError:
                pass

        self.current_screen = None

    def show_login(self):
        """Display the login screen."""
        self.clear_screen()
        self.root.title("CICO E-Wallet - Login")

        self.current_screen = LoginPage(
            self.root,
            on_success=self.show_dashboard
        )

    def show_dashboard(self, username):
        """Display the dashboard after a successful login."""
        self.clear_screen()
        self.root.title("CICO E-Wallet - Dashboard")

        try:
            self.current_screen = Dashboard(
                self.root,
                username=username,
                on_logout=self.show_login
            )
        except Exception as error:
            traceback.print_exc()

            messagebox.showerror(
                "Dashboard Error",
                f"Unable to open the dashboard:\n\n{error}",
                parent=self.root
            )

            # Return to the login screen if the dashboard fails to open.
            self.show_login()

    def close_app(self):
        """Close the application safely."""
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    CICOApp().run()
